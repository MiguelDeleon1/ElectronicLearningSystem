﻿namespace Electronic_Learning_System.Models
{
    public class User
    {
        // F i e l d s & P r o p e r t i e s
        public int DODID { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Occupation { get; set; }
        public string Title { get; set; }

        // C o n s t r u c t o r s

        // M e t h o d s

    }
}
